from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader


# Create your views here.
def home(request):
    return render(request, 'main/index.html')

def vivek(request,val):
    t=loader.get_template('main/new.html')
    context={
      'val':val
    }
    return HttpResponse(t.render(context,request))

def action(request):
    a=request.POST['n1']
    return HttpResponse("thank you AGE: %s"%a)